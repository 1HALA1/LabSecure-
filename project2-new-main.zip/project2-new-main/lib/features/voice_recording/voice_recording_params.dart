class VoiceRecordParams {
  final bool? isFirstTime;
  VoiceRecordParams({this.isFirstTime = false});
}

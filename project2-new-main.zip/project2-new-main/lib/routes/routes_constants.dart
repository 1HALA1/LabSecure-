class RoutesConstants {
  static const voiceRecording = "/voice-recording";
}
